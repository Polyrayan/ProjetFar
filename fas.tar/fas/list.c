/**
begin
insert
erase
empty
**/

typedef struct node{
    pPair data;
    struct node* next;
}node;

node* create(pPair data,node* next)
{
    node* new_node = (node*)malloc(sizeof(node));
    if(new_node == NULL)
    {
        printf("Error creating a new node.\n");
        exit(0);
    }
    new_node->data = data;
    new_node->next = next;
 
    return new_node;
}

node* insert(node* head, pPair data)
{
    // go to the last node 
    
    node* new_node =  create(data,NULL);
    new_node->next = head;

    /*
    node *cursor = head;
    while(cursor->next != NULL){
        cursor = cursor->next;
    }   
        
 
    // create a new node 
    node* new_node =  create(data,NULL);
    cursor->next = new_node;
    */
    return new_node;
}


int empty(node* list){
   if (list == NULL){
   	return 1;
   }else{
   	return 0;
   }
}

pPair begin(node* list){
    return list->data;   
}

node* remove_back(node* head)
{
    if(head == NULL)
        return NULL;
 
    node *cursor = head;
    node *back = NULL;
    while(cursor->next != NULL)
    {
        back = cursor;
        cursor = cursor->next;
    }
    if(back != NULL)
        back->next = NULL;
 
    /* if this is the last node in the list*/
    if(cursor == head)
        head = NULL;
 
    free(cursor);
 
    return head;
}

node* remove_front(node* head)
{
    if(head == NULL)
        return NULL;
    node *front = head;
    head = head->next;
    front->next = NULL;
    /* is this the last node in the list */
    if(front == head)
        head = NULL;
    free(front);
    return head;
}

node* erase(node* head,node* nd)
{
    /* if the node is the first node */
    if(nd == head)
    {
        head = remove_front(head);
        return head;
    }
 
    /* if the node is the last node */
    if(nd->next == NULL)
    {
        head = remove_back(head);
        return head;
    }
 
    /* if the node is in the middle */
    node* cursor = head;
    while(cursor != NULL)
    {
        if(cursor->next == nd)
            break;
        cursor = cursor->next;
    }
 
    if(cursor != NULL)
    {
        node* tmp = cursor->next;
        cursor->next = tmp->next;
        tmp->next = NULL;
        free(tmp);
    }
    return head;
}